package com.app;

import org.junit.Test;


class CRMTests {

	@Test
	void contextLoads() {
	}

}
